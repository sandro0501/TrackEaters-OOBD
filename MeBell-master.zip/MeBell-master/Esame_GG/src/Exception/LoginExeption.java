package Exception;

public class LoginExeption extends Exception {

}
