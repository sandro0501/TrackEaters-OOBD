# EsameUniNA-GG
Esame progetto OO/BDD - Garofalo/Gargiulo

Repository per il progetto OO/BDD a.a 2019/2020 di:

```
Federico Gargiulo - N86002884
Antonio Garofalo - N86003129
```

Utilizzata versione Java: 11.0.5 LTS (aggiornata a 11.0.10).
